var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var io = require('socket.io');
var five = require("johnny-five"),
    // or "./lib/johnny-five" when running from the source
    board = new five.Board();


var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

var httpProxy = require('http-proxy');
var apiProxy = httpProxy.createProxyServer();
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function(err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

app.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.get("/api/*",function(req,res){
    apiProxy.web(req,res, { target: 'http://google.com:80'});
});

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

// From ./bin/www

var debug = require('debug')('BlinkSP');

app.set('port', process.env.PORT || 3000);


var server = app.listen(app.get('port'), function() {
  debug('Express server listening on port ' + server.address().port);
});

function strobe() {
board.on("ready",function() {
    var led = five.Led(13);

    led.strobe();

});
};



var io = require('socket.io').listen(server);

board.on("ready", function() {
    led = new five.Led(13);

    function finger(pi) {
        this.pin = pi;
        this.servo = new five.Servo({
                            pin: pi,
                            range: [70,110],});
        this.servo.sweep();
        this.toggle = function(speed) {
          //this.servo.to((180 - this.orientation),speed);
          q=q
        }
        this.e0 = function() {
            this.servo.sweep();
            console.log('this works')
        };
        this.e1 = function() {
            this.servo.sweep();
        };
        this.e2 = function() {
            this.servo.sweep();
        };
        this.e3 = function() {
            var q=1
            this.servo.sweep();
        };
    }

    f0 = new finger(2)
    f1 = new finger(3)
    f2 = new finger(4)
    f3 = new finger(5)
    f4 = new finger(6)
    led = five.Led(13)
/*    io.on('connection', function(socket){
      /*console.log('a user connected');

      socket.on('led', function(data) {
        q=q;
      });

      socket.on('0.0', function(data) {

        f0.e0;
      });

      socket.on('0.1', function(data) {
        f1.e0();
      });

      socket.on('0.2', function(data) {
        f2.e0();
      });

      socket.on('0.3', function(data) {
        f3.e0();
      });

      socket.on('0.4', function(data) {
        f4.e0();
      });

      socket.on('1.0', function(data) {
        f0.e1();
      });

      socket.on('1.1', function(data) {
        f1.e1();
      });

      socket.on('1.2', function(data) {
        f2.e1();
      });

      socket.on('1.3', function(data) {
        f3.e1();
      });

      socket.on('1.4', function(data) {
        f4.e1();
      });

      socket.on('2.0', function(data) {
        f0.e2();
      });

      socket.on('2.1', function(data) {
        f1.e2();
      });

      socket.on('2.2', function(data) {
        f2.e2();
      });

      socket.on('2.3', function(data) {
        f3.e2();
      });

      socket.on('2.4', function(data) {
        f4.e2();
      });

      socket.on('3.0', function(data) {
        led.toggle();
        //f0.e3();
      });

      socket.on('3.1', function(data) {
        f1.e3();
      });

      socket.on('3.2', function(data) {
        f2.e3();
      });

      socket.on('3.3', function(data) {
        f3.e3();
      });

      socket.on('3.4', function(data) {
        f4.e3();
      });*/
      

      /*socket.on('ledOn', function(data) {
        led.toggle();
        console.log("LED is on!");

      });*/

   /* });*/
});

module.exports = app;
