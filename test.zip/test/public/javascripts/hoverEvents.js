$(document).ready(function(){

    ion.sound({
        sounds: [
            {name: "beer_can_opening"},
            {name: "bell_ring"},
            {name: "branch_break"},
            {name: "snap"}
        ],
        path: "sounds/",
        preload: true,
        volume: 1.0
    });

    var socket = io();

    $("a").mouseenter(function (event, num){
        ion.sound.play("beer_can_opening");
        socket.emit(0 + '.' + num);
    });
    $("button").mouseenter(function (event, num){
        ion.sound.play("bell_ring");
        socket.emit(1 + '.' + num);
    });
    $("h1").mouseenter(function (event, num){
        ion.sound.play("snap");
        socket.emit(2 + '.' + num);
    });
    $("img").mouseenter(function (event, num){
        ion.sound.play("branch_break");
        socket.emit(3 + '.' + num);
    });
    $("button").click(function (event, num){
        socket.emit('ledOn');
    });
});