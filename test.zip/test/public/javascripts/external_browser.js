$(document).ready(function(){
console.log('ajksdhfgkas');
	var iframe = document.getElementById('ifrm');
	var innerDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;

	var ulObj = innerDoc.getElementsByTagName('body');

	/*ulObj.attachEvent("onclick", function(){
    	console.log('asdjhg');
	});*/

	$('#ifrm').load('https://www.google.com');
});

/*$(function() { 
        var $frame = $('<iframe style="width:200px; height:100px;">'); 
        $('body').html( $frame ); 
        setTimeout( function() { 
            var doc = $frame[0].contentWindow.document; 
            var $body = $('body',doc); 
            $body.html('<h1>Test</h1>'); 
        }, 1 ); 
});


  Event.observe(window, 'load', function() {
    $$('a').each(function(e) {
      e.writeAttribute('target', '_parent');
   });
 });
/*
$('a').click( function(){ 
	$('body').load("<iframe src='"+ this.attr('href') +"'></iframe>");
	console.log('this is doing something...');
});*/